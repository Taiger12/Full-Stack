package com.codigo.feign.Aggregates.Request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmpresaRequest {

    private String tipoDoc;
    private String numDoc;

}
