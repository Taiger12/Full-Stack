package com.codigo.feign.Aggregates.Constants;

public class Constants {

    public static final Integer CODE_SUCCESS=200;
    public static final Integer CODE_ERROR=10400;
    public static final String MESS_SUCCESS="Ejecución correcta";
    public static final String MESS_ERROR="Error en la Ejecución";


}
