package com.codigo.feign.Service;

public interface TipoDocumentoService {
}
